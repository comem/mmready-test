<?php

echo '
        [{"id":"3",
        "name":"Romain",
        "stagename":"Remixed",
        "created_at":"2014-05-26 14:22:41",
        "updated_at":"2014-06-02 09:47:42",
        "instruments":[
        {"id":"2","musician_id":"3","name":"Guitar"},
        {"id":"3","musician_id":"3","name":"Bass"},
        {"id":"4","musician_id":"3","name":"Clarinette"}]},
        {"id":"4",
        "name":"Naty",
        "stagename":"Remixed",
        "created_at":"2014-05-26 14:22:41",
        "updated_at":"2014-06-02 09:47:42",
        "instruments":[
        {"id":"2","musician_id":"3","name":"Drums"},
        {"id":"3","musician_id":"3","name":"Piano"}]}]
        
	
';