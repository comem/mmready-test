<?php 

echo '{
    "status" : "error",
    "message" : "A title is required"
}';

?>