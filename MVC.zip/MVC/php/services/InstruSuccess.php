<?php 

echo '{
	"status" : "success",
	"data" : [{ "id" : 1, "musician_id":"3", "name" : "Guitar" },
        { "id" : 2, "name" : "Bass" },
        { "id" : 3, "name" : "Vocal" }]
        
	
}';


    
?>