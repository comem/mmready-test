<?php 

echo '{
	status : "success",
	data : [{ "id" : 1, "name" : "Romain", "instruments":{"id" : 1, "name" : "Bass" }},
        { "id" : 2, "name" : "Clélia", "instruments":[{"id" : 2, "name" : "Guitar" },{"id" : 3, "name" : "Vocal" }] },
        { "id" : 3, "name" : "Maya", "instruments":[{"id" : 4, "name" : "Drums" },{"id" : 3, "name" : "Vocal" }] }]
        
	
}';


    
?>