<?php 

echo '{"status":"success","lang": [{"txtBtnAdd":"Ajouter"},{"txtBtnDel":"Effacer"},{"txtBtnEdit":"Editer"}] }';


    
?>