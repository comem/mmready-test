<?php 

echo '{
"status" : "success",
 "data" : [{"title":"La grosse fiesta 2014",
          "artists":[
                     {"name":"mmready()",
                     "musicians":[
                                  {"name":"Romain","instruments":[{"name":"Bass"}]},
                                  {"name":"Clélia","instruments":[{"name":"Vocal"}]}
                                 ]},
                     

                     {"name":"ZED","musicians":[]}
                     ]
        }]
        
       }';


    
?>


    