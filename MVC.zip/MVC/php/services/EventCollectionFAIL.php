<?php 

echo '{
    "status" : "fail",
    "data" : { "title" : "A title is required" }
}';

?>