 $.holdReady(true);  
 $.getScript('js/main.js', function(){
     $.holdReady(false);
 });