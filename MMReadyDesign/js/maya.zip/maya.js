var templateMusician;
var templateTicket;
var templateImage;
var templateLink;
var templateArtist;
var nbMusicianstoCompare;
var templateMusicianApercu;

var nbMucicians = 0;
var nbTickets = 2;
var nbArtist = 1;
var nbLinks = 1;
var nbImages = 1;

$(document).ready(function() {
//masque les messages d'erreur
    $('#alertArtist').hide();
    $('#alertMusician').hide();
    //cloner les templates
    templateTicket = $('.ticket').clone();
    templateMusician = $('.musician').clone();
    templateMusicianApercu = $('.musicianApercu').clone();
    templateImage = $('.image').clone();
    templateLink = $('.link').clone();


    //vider les champs
    $('.musicians').empty();
    $('#listMusicians').empty();
    $('.images').empty();
    $('.links').empty();
    //cloner le template d'artiste
    templateArtist = $('.artist').clone();
    //
    $('#artists').empty();

    $('#addTicketCategory').on('click', addTicket);
    $('#addArtist').on('click', addArtist);

    //$('#addInstrument').click(addInstrument);
});

////***********************************************************************************
////*************************************TICKETS***************************************
////***********************************************************************************
function addTicket() {
    var ticket = templateTicket.clone();
    //cloner et rajouter au dom
    $(ticket).clone().appendTo("#selectTicket");
    //modifier l'id du dernier élément ajouté
    $(".ticket").last().attr('id', 'ticket_' + nbTickets);
    //faire apparaître
    $(".ticket").last().removeClass('hide');
    //ajouter le bouton supprimer
    $('<button class="deleteTicket"><i class="ico-delete "></i>Supprimer</button> ').appendTo($(".ticket").last());
    //supprimer un ticket
    $('.deleteTicket').on('click', deleteTicket);
    nbTickets++;
}

function deleteTicket() {
    $(this).parent().remove();
    nbTickets--;
}

//***********************************************************************************
//*************************************MUSICIEN**************************************
//***********************************************************************************
function addMusician() {
    nbMusicianstoCompare = $('.musicianApercu').length;
    if (nbMucicians === nbMusicianstoCompare) {
        //cloner le template de musicien
        var musician = templateMusician.clone();
        //cloner et rajouter le musicien au DOM
        $(musician).clone().appendTo(".musicians");
        //modifier l'id du dernier élément ajouté
        var nextID = nbMucicians+1;
        $(".musician").last().attr('id', 'musician_' + nextID);
        //supprimer un musicien
        $('.deleteMusician').on('click', deleteMusician);
        //sauvegarder un musicien
        $('.saveMusician').on('click', saveMusician);
        //incrémenter le nombre de musiciens
        nbMucicians++;
    } else {//afficher une alerte si un musicien est en cours de création
        $('#alertMusician').toggle(1000).delay(2000).toggle(1000);
    }
}

function deleteMusician() {
    $(this).parent().remove();
    nbMucicians--;
}

function saveMusician() {
    var musicianApercu = templateMusicianApercu.clone();
    var firstName = $(this).parent().find('input[data-key=musicianFirstName]').val();
    var lastName = $(this).parent().find('input[data-key=musicianLastName]').val();
    var sceneName = $(this).parent().find('input[data-key=musicianScenetName]').val();
    var instrument = $(this).parent().find('select[data-key=instrument]').val();
    $(musicianApercu).find('span').text(firstName + ' ' + lastName);
    $(musicianApercu).attr('data-key',nbMucicians)
    $(musicianApercu).appendTo('#listMusicians');
    $(this).parent().hide();
    $('.musicianApercuDelete').on('click', musicianApercuDelete);
$('.musicianApercuEdit').on('click', musicianApercuEdit);
}

function musicianApercuDelete() {
    
    var idencours = $(this).parent().attr('data-key');
    var idAsuppr = 'musician_'+idencours;
    $(this).parent().parent().next().find('div[id='+idAsuppr+']').remove();
    $(this).parent().remove();  
    nbMucicians --;
    alert(nbMucicians);
}

function musicianApercuEdit(){
    
}
//***********************************************************************************
//*************************************IMAGE**************************************
//***********************************************************************************
function addImage() {
    var image = templateImage.clone();
    //récupérer le nombre de ticket actuellement visibles
    var nb = $(".image").length;
    //incrémenter l'id du prochain musicien
    var nextId = nb + 1;
    //cloner et rajouter au dom
    $(image).clone().appendTo(".images");
    //modifier l'id du dernier élément ajouté
    $(".image").last().attr('id', 'image_' + nextId);
    //supprimer une image
    $('.deleteImage').click(deleteImage);
}

function deleteImage() {
    $(this).parent().remove();
}

//***********************************************************************************
//*************************************LINKS**************************************
//***********************************************************************************
function addLink() {
    var image = templateLink.clone();
    //récupérer le nombre de ticket actuellement visibles
    var nb = $(".link").length;
    //incrémenter l'id du prochain musicien
    var nextId = nb + 1;
    //cloner et rajouter au dom
    $(image).clone().appendTo(".links");
    //modifier l'id du dernier élément ajouté
    $(".link").last().attr('id', 'link_' + nextId);
    //supprimer un lien
    $('.deleteLink').click(deleteLink);
}

function deleteLink() {
    $(this).parent().remove();
}

//***********************************************************************************
//*************************************ARTIST**************************************
//***********************************************************************************
function addArtist() {
    if ($('#artists').is(':empty')) {
        var artist = templateArtist.clone();
        //récupérer le nombre de ticket actuellement visibles
        var nbArtists = $(".artist").length;
        //incrémenter l'id du prochain musicien
        var nextId = nbArtists + 1;
        //cloner et rajouter au dom
        $(artist).clone().appendTo("#artists");
        //modifier l'id du dernier élément ajouté
        $(".artist").last().attr('id', 'artist_' + nextId);
        //supprimer un musicien
        $('.deleteArtist').click(deleteArtist);
        //sauvegarder un artist
        $('.saveArtist').click(saveArtist);

        //ajouter une image
        $('#addImage').on('click', addImage);

        //ajouter un musicien
        $('#addMusician').click(addMusician);

        //ajouter un lien
        $('#addLink').on('click', addLink);
        //sauvegarder un artist
        $('.saveArtist').click(saveArtist);

    } else {
        $('#alertArtist').toggle(1000).delay(2000).toggle(1000);
    }
}

function deleteArtist() {
    $(this).parent().remove();
}

function saveArtist() {

}

function saveArtist() {
}

//***********************************************************************************
//*************************************INSTRUMENt************************************
//***********************************************************************************
//function addInstrument() {
//    //récupérer le nombre de ticket actuellement visibles
//    var nbInstruments = $(".instrument").length;
//    //incrémenter l'id du prochain ticket
//    var nextId = nbInstruments + 1;
//    //cloner et rajouter au dom
//    $(".instrument").first().clone().appendTo("#instruments");
//    //modifier l'id du dernier élément ajouté
//    $(".instrument").last().attr('id', 'instrument_' + nextId);
//    //faire apparaître
//    $(".instrument").last().removeClass('hide');
//    //supprimer un musicien
//    $('.deleteInstrument').click(deleteInstrument);
//
//}
//
//function deleteInstrument() {
//    $(this).parent().remove();
//}
